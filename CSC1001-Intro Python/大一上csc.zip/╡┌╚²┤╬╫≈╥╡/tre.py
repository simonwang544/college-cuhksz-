a=str(1.0)
b=str(1)
print(a==b)