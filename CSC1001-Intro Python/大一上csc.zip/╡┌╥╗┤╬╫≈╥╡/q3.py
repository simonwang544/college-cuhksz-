x=int(input("Enter a positive integer:"))
i=0
while True:
    if i**2>x:
        print(i)
        break
    else:
        i+=1