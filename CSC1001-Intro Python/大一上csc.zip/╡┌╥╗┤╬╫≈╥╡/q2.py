number =input("Enter an integer:")
for i in number:
    print(i)