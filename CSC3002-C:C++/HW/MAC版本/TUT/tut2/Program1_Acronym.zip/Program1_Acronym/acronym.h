#ifndef ACRONYM_H
#define ACRONYM_H

#include <cctype>
#include <iostream>
#include <string>
using namespace std;

/* Function prototypes */

string acronym(string str);

#endif