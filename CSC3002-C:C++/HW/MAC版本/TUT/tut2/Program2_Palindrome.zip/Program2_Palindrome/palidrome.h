#ifndef PALIDROME_H
#define PALIDROME_H

#include <iostream>
#include <string>
using namespace std;

/* Function prototypes */

bool isPalindrome(string str);

#endif