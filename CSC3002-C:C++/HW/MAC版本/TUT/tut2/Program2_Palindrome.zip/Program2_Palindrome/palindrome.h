#ifndef PALINDROME_H
#define PALINDROME_H

#include <iostream>
#include <string>
using namespace std;

/* Function prototypes */

bool isPalindrome(string str);

#endif