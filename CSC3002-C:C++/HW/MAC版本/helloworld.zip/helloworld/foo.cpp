#include <iostream>

using namespace std;

void foo(const string& msg) {
	cout << "welcome to CSC3002" << endl;
	cout << msg << endl;
	cout << endl;
}