#include "helloworld.h"

int main() {
	foo("I love IT !!!!!");
	return 0;
}