#include <iostream>
#include "foo.h"

using namespace std;