#include <iostream>

void foo(const std::string & msg);