/* Q2: 
 * File: FindDNAMatch.cpp
 * ----------------------
 * This file solves the DNA matching exercise from the text.
 */
// header file for OJ system
// #include <iostream>
// #include <string>

// using namespace std;

#include <iostream>
#include <string>
#include "csc300222fall/assignment1/FindDNAMatch.h" //for OJ
using namespace std;


/*
 * Function: findDNAMatch
 * Usage: int pos = findDNAMatch(s1, s2);
 *        int pos = findDNAMatch(s1, s2, start);
 * ---------------------------------------------
 * Returns the first index position at which strand s1 would bind to
 * the strand s2, or -1 if no such position exists.  If the start
 * parameter is supplied, the search begins at that index position.
 */

int findDNAMatch(string s1, string s2, int start) {
   // TODO
   return s2.find(matchingStrand(s1), start);
}

/*
 * Function: matchingStrand
 * Usage: string match = matchingStrand(strand);
 * ---------------------------------------------
 * Returns a string in which each base has been replaced by its
 * counterpart base (C <-> G and A <-> T).  Any other characters
 * are replaced by an X.
 */

string matchingStrand(string strand) {
   // TODO
   string result = "";
   for (int i=0; i < strand.length(); i++){
      if (strand[i] == 'A'){
         result += 'T';
      }
      else if (strand[i] == 'T'){
         result += 'A';
      }
      else if (strand[i] == 'G'){
         result += 'C';
      }
      else if(strand[i] == 'C'){
         result += 'G';
      }
      else{
         result += 'X';
      }
   }
   return result;
}

/*
 * Function: findAllMatches
 * Usage: findAllMatches(s1, s2);
 * ------------------------------
 * Finds all positions at which s1 can bind to s2.
 */

void findAllMatches(string s1, string s2) {
   // TODO
   cout << s1 << " matches " << s2 << " at";
   for (int i = 0; i <= (s2.length()-s1.length()) ;){
      i = findDNAMatch(s1, s2, i);
      if (i == -1) break;
      cout << " position " << i ;
      i++;
      
   }
   cout << endl;

}

// DO NOT modify the main() function
/*
 * sample output:
 * input:  TTGCC TAACGGTACGTC
 * output: TTGCC matches TAACGGTACGTC at position 1
*/
int main(int argc, char* argv[]) {
    string s1, s2;
    cin >> s1 >> s2; 
    findAllMatches(s1, s2);
    return 0;
}
