/*
 * File: BanishLetters.cpp
 * -----------------------
 * This program removes all instances of a set of letters from
 * an input file.
 */

#include <iostream>
#include <algorithm>
#include "csc300222fall/assignment1/lib.h" //for local version
using namespace std;


int banishLetters() {
   // TODO
   char ch;
   string banishedLetters;
   string lowerCase = "";
   string upperCase = "";
   getline(cin, banishedLetters);
   for (auto i : banishedLetters){
       if (i <= 'Z'){
              lowerCase += i+32;// 32 = 'a' - 'A' according to ASCII.
              upperCase += i;
       }
       else{
              lowerCase += i;
              upperCase += i-32;
       }
   }

   while(cin.get(ch)){
       if (upperCase.find(ch) == upperCase.npos && lowerCase.find(ch) == lowerCase.npos){
             cout << ch; 
       }
       
   }
   return 0;
}


/* DO NOT modify this main() part */
/*
 sample output:
 input: S
        this is a testing 1
        this is a testing 2
 output:
        thi i a teting 1
        thi i a teting 2
*/
int main(int argc, char* argv[]) {
    banishLetters();
    return 0;
}
