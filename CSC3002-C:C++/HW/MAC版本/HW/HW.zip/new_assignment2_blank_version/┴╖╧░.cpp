#include <iostream>
#include <string>
#include <map>
#include "csc300222fall/assignment2/lib.h" 
#include "csc300222fall/assignment2/morsecode.h" 
using namespace std;
int main() {
    string str1 = "simon";
    cout<< str1[1]<<endl;
    char str2 = str1[2];







    return 0;
}