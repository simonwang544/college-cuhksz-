goods_list = ['apple', 'orange', 'cola', 'juice', 'banana']
price_list = [3, 4, 5, 6, 4]

#No arguement, no return.
def show_goods():
    # global goods_list
    # global price_list
    print('Goods'.ljust(10), 'Price')
    for i in range(len(goods_list)):
        print((goods_list[i] + ':').ljust(10), price_list[i])

#Three arguments, including one default argument. One return value.
def buy_goods(p_balance, p_name, p_number = 1,):
    # global goods_list
    # global price_list
    if not p_name in goods_list:
        print('No this goods.')
        return p_balance
    index = goods_list.index(p_name)
    cost = p_number * price_list[index]
    if cost > p_balance:
        print('Balance is not enough, please add more money.')
    else:
        p_balance -= cost
        print('Buy successfully.')
    return p_balance

show_goods()

print('Your balance:', buy_goods(20,'appe',3))
print('Your balance:', buy_goods(20,'apple',3))