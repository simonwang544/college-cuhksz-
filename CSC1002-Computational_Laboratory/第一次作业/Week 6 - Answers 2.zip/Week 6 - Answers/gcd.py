# # # # #finding the gcd of two positive integers


# def gcd(a, b): # a=12, b=24
#     low = min(a, b)
#     high = max(a, b)

#     if low == 0:
#         return high
#     elif low == 1:
#         return 1
#     else:
#         return gcd(low, high%low)  # recursively call function.
#     # gcd(gcd(gcd(gcd(..util break...gcd...))))  


# # print(gcd(12,13))
# # print(gcd(12,16))




# def func(a=1, *args):
#     print(type(args))
#     print('args:', args)


# # def func1(**kwargs):
# #     print(type(kwargs))
# #     print(kwargs)
    
# # func1(a=1,b=2)

# x = 2

# def local_func():
#     global x
#     x = 4
#     print('x in local:', x)
    
# local_func()
# print('x:', x)


# decorator:

import time

# three layer decorator:
def three_layer_deco(arg1, arg2):
    def current_time(func):
        def wrap(**kwarg):
            print('current time is:', time.strftime('%H:%M:%S', time.localtime()))
            print(f'{arg1} is {arg2} me!!!!')
            res = func(**kwarg)
            return res
        print('addr in currentime:', id(wrap))  # id return the address of the var.
        return wrap   # reference of wrap function.
    
    return current_time

@three_layer_deco('func1', 'calling') 
def func1(**kwarg):
    print('func1')
    return '12222222'

@three_layer_deco('func2', 'invoking') 
def func2(**kwarg):
    print('func2')
    return '2'
    
func1(a=1)
func2(a=2)
