goods_list = ['apple', 'orange', 'cola', 'juice', 'banana']
price_list = [3, 4, 5, 6, 4]

#Two arguements, one return value.
def add_money(p_money, p_balance):
    list_money = [5, 10, 20, 50, 100]
    if not p_money in list_money:
        print('Wrong face value.')
    else:
        p_balance += p_money
        print('Pay successfully.')
    return p_balance

#No arguement, no return.
def show_goods():
    # global goods_list
    # global price_list
    print('Goods'.ljust(10), 'Price')
    for i in range(len(goods_list)):
        print((goods_list[i] + ':').ljust(10), price_list[i])

#Three arguments, including one default argument. One return value.
def buy_goods(p_balance, p_name, p_number = 1):
    # global goods_list
    # global price_list
    if not p_name in goods_list:
        print('No this goods. You can use "show" to see goods list.')
        return p_balance
    index = goods_list.index(p_name)
    cost = p_number * price_list[index]
    if cost > p_balance:
        print('Balance is not enough, please add more money.')
    else:
        p_balance -= cost
        print('Buy successfully.')
    return p_balance

def main():
    balance = 0
    while True:
        print('Enter "add" to add money')
        print('Enter "show" to see goods list')
        print('Enter "buy" to buy goods')
        print('Enter "stop" to quit')
        instruction = input('Your instruction:')
        if instruction == 'stop':
            print('Thank you for your patronage.')
            break
        elif instruction == 'show':
            show_goods()
        elif instruction == 'add':
            money = int(input('Face value:'))
            balance = add_money(money,balance)
            print('Your balance:', balance)
        elif instruction == 'buy':
            goods = input('The goods you want to buy:')
            number = int(input('How many:'))
            balance = buy_goods(balance,goods,number)
            print('Your balance:', balance)
        else:
            print("Wrong instruction,please enter again.")

main()