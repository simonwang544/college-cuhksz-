#Two arguements, one return value.


def add_money(p_money, p_balance):
    list_money = [5, 10, 20, 50, 100]
    if p_money not in list_money:
        print('Wrong face value.')
    else:
        p_balance += p_money
        print('Pay successfully.')
    return p_balance

print('Your balance:', add_money(10,2))
